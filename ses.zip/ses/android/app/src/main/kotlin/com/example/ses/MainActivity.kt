package com.example.ses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
